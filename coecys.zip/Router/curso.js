const lstCurso= require('./../models/listaCurso');
const curso= require('./../models/Cursos');

const expres= require('express');

const handleCurso= new lstCurso();

const routerCurso = ()=>{
    const router = expres.Router();
    /*
        get enviar dato en bd select
        post recibir datos en bd insert
        put recibi datos en bd update
        delete borrar datos en bd delete
    */
    //router.get
        const obj = new curso(1,"IPC2","A","USAC"); 
        const obj2 = new curso(2,"IPC1","B","USAC");
        const obj3= new curso(1,"OTRO","A","mariano");

        handleCurso.agregarCurso(obj);
        handleCurso.agregarCurso(obj3);
        handleCurso.agregarCurso(obj2);

        router.get('/verCursos',(request,response)=>{
            response.send(handleCurso.obtenerCursos());
        });

        router.post('/agregarCurso',(request,response)=>{
            const{codigo,nombre, seccion, universidad}= request.body;
            const nuevoCurso= new curso(codigo,nombre,seccion,universidad);
            handleCurso.agregarCurso(nuevoCurso);
            response.send("Curso Creado");
        })

        router.put('/modificarCurso/:id',(request,response)=>{
            const codigo= request.params.id;
            const curso= request.body;

            const status = handleCurso.modificarCurso(codigo,curso);
            if(status){
                response.send('Se modifico correctamente');
            }else{
                response.send('No se encontró el curso a modificar');
            }
        })

        router.delete('/borrarCurso/:codigo',(request,response)=>{
            const codigo= request.params.codigo;
            const status= handleCurso.borrarCurso(codigo);
            if(status)
                response.send('Se elimino el curso')
            else
                response.send('No se encontró')
        })

        router.get('/filtrarUniversidad/:universidad',(request,response) =>{
            const universidad = request.params.universidad;
            const status = handleCurso.buscarCursoUniversidad(universidad);
            if(status)
                response.send(status);
            else
                response.send(`No hay curso de la Universidad ${universidad}`);
        })
    return router;
}

module.exports=routerCurso;