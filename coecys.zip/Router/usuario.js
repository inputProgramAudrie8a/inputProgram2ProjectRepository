const lstUsuarios= require('./../models/lstUsuario');
const usuario= require('./../models/Usuario');

const expres= require('express');

const handle= new lstUsuarios();

const routerUsuario = ()=>{
    const router = expres.Router();
    /*
        get enviar dato en bd select
        post recibir datos en bd insert
        put recibi datos en bd update
        delete borrar datos en bd delete
    */
    //router.get
        const obj = new usuario(201810263, "Juan", "10/12/1999", "ann.audrie8a@gmail.com", "USAC", "Audrie8a", "7024", "Administrador"); 
        const obj2 = new usuario(201810264, "Juana", "10/12/1999", "juana@gmail.com", "USAC", "Audrie8a", "7024", "Administrador");
        const obj3= new usuario(201810265, "Juanes", "10/12/1999", "jaunes@gmail.com", "USAC", "Audrie8a", "7024", "Administrador");

        handle.agregarUsuario(obj);
        handle.agregarUsuario(obj3);
        handle.agregarUsuario(obj2);

        router.get('/verUsuarios',(request,response)=>{
            response.send(handle.obtenerUsuario());
        });

        router.post('/agregarUsuarios',(request,response)=>{
            const{carne, nombre, fecha, correo, universidad, nickname, contrasena, rol}= request.body;
            if(!carne||!nombre||!fecha||!correo||!universidad||!nickname||!contrasena||!rol){
                response.send('Se debe ingresar todos los datos que se le piden');
                return;
            }else{
                const nuevoUsuario= new usuario(carne, nombre, fecha, correo, universidad, nickname, contrasena, rol);
                handle.agregarUsuario(nuevoUsuario);
                response.send("Usuario Registrado");
            }
            
        })

        router.put('/modificarUsuario/:id',(request,response)=>{
            const carne= request.params.id;
            const usuario= request.body;

            const status = handle.modificarUsuario(carne,usuario);
            if(status){
                response.send('Se modifico correctamente');
            }else{
                response.send('No se encontró el usuario a modificar');
            }
        })

        router.delete('/borrarUsuario/:carne',(request,response)=>{
            const carne= request.params.carne;
            const status= handle.borrarUsaurio(usuario);
            if(status)
                response.send('Se elimino el curso')
            else
                response.send('No se encontró')
        })

        
    return router;
}

module.exports=routerUsuario;