class listaCuros{
    constructor(){
    this.cursos=[];
    }

    obtenerCursos(){
        return this.cursos;
    }
    agregarCurso(cursos){
        this.cursos.push(cursos);
    }
    borrarCurso(codigo){
        const index =this.cursos.findIndex(item=> item.codigo==codigo);
        if(index >=0){
            this.cursos.splice(index, 1);
            return true;
        }else{
            return false;
        }
    }
    modificarCurso(codigo, cursos) {
        let index = this.cursos.findIndex(cursos => cursos.codigo == codigo);

        if (index >= 0) {

            this.cursos[index].codigo = cursos.codigo;
            this.cursos[index].nombre = cursos.nombre;
            this.cursos[index].seccion = cursos.seccion;
            this.cursos[index].universidad = cursos.universidad;
            
            return true;
        }
        return false;
    }
    buscarCursoUniversidad(universidad){
        const result= this.cursos.filter(curso => curso.universidad == universidad);
        
        if(result){
            return result;
        }else{
            return false;
        }
    }
    
}

module.exports =listaCuros;