class Curso {
    constructor(codigo, nombre, seccion, universidad) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.seccion = seccion;
        this.universidad = universidad;
    }
}

module.exports = Curso;