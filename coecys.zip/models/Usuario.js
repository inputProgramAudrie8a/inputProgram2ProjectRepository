class Usuario {
    constructor(carne, nombre, fecha, correo, universidad, nickname, contrasena, rol) {
        this.carne = carne;
        this.nombre = nombre;
        this.fecha = fecha;
        this.correo= correo;
        this. universidad=universidad;
        this.nickname=nickname;
        this.contrasena=contrasena;
        this.rol = rol;
    }
}

module.exports = Usuario;