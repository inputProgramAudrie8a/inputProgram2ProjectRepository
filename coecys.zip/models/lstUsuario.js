class listaUsuarios{
    constructor(){
    this.usuarios=[];
    }

    obtenerUsuario(){
        return this.usuarios;
    }
    agregarUsuario(usuarios){
        this.usuarios.push(usuarios);
    }
    borrarUsuario(carne){
        const index =this.usuarios.findIndex(item=> item.carne==carne);
        if(index >=0){
            this.usuarios.splice(index, 1);
            return true;
        }else{
            return false;
        }
    }
    modificarUsuario(carne, usuarios) {
        let index = this.usuarios.findIndex(usuarios => usuarios.carne == carne);

        if (index >= 0) {

            this.usuarios[index].carne = usuarios.carne;
            this.usuarios[index].nombre = usuarios.nombre;
            this.usuarios[index].fecha = usuarios.fecha;
            this.usuarios[index].correo= usuarios.correo;
            this.usuarios[index].universidad=usuarios.universidad;
            this.usuarios[index].nickname=usuarios.nickname;
            this.usuarios[index].contrasena=usuarios.contrasena;
            this.usuarios[index].rol=usuarios.rol;
            
            
            return true;
        }
        return false;
    }
    
    
}

module.exports =listaUsuarios;